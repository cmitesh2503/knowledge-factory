"""
Google Document AI service wrapper.
"""

import json
from pathlib import Path

from google.cloud import documentai
from google.api_core.client_options import ClientOptions
from google.protobuf.json_format import MessageToDict


class DocumentAIService:
    """Wrapper around Google Document AI."""

    def __init__(
        self,
        project_id: str,
        location: str,
        processor_id: str,
    ) -> None:

        opts = ClientOptions(
            api_endpoint=f"{location}-documentai.googleapis.com"
        )

        self.client = documentai.DocumentProcessorServiceClient(
            client_options=opts
        )

        print(f"Using endpoint: {location}-documentai.googleapis.com")

        self.processor_name = self.client.processor_path(
            project_id,
            location,
            processor_id,
        )

    def process_file(self, file_path: str):
        pdf_bytes = Path(file_path).read_bytes()

        print(f"Bytes sent to Document AI: {len(pdf_bytes)}")
        print(f"PDF header: {pdf_bytes[:16].hex()}")

        raw_document = documentai.RawDocument(
            content=pdf_bytes,
            mime_type="application/pdf",
        )

        request = documentai.ProcessRequest(
            name=self.processor_name,
            raw_document=raw_document,
        )

        print(">>> BEFORE process_document")

        response = self.client.process_document(
            request=request
        )

        print(">>> AFTER process_document")
        print(f">>> process_document response type: {type(response)}")

        # ---------------------------------------------------------
        # Diagnostic only: inspect document_layout
        # ---------------------------------------------------------

        print(">>> DOCUMENT AI DIAGNOSTICS START")

        document_dict = MessageToDict(
            response.document._pb,
            preserving_proto_field_name=True,
        )

        print(
            f">>> DOCUMENT AI top-level keys: "
            f"{list(document_dict.keys())}"
        )

        document_layout = document_dict.get("document_layout")

        if document_layout is None:
            print(">>> DOCUMENT AI document_layout: NONE")
        else:
            print(
                f">>> DOCUMENT AI document_layout type: "
                f"{type(document_layout).__name__}"
            )

            if isinstance(document_layout, dict):
                print(
                    f">>> DOCUMENT AI document_layout keys: "
                    f"{list(document_layout.keys())}"
                )

            def describe_structure(value, depth=0, max_depth=5):
                indent = "  " * depth

                if depth > max_depth:
                    print(f"{indent}<max depth reached>")
                    return

                if isinstance(value, dict):
                    print(
                        f"{indent}DICT keys={list(value.keys())}"
                    )

                    for key, child in value.items():
                        print(
                            f"{indent}{key}:"
                        )
                        describe_structure(
                            child,
                            depth + 1,
                            max_depth,
                        )

                elif isinstance(value, list):
                    print(
                        f"{indent}LIST count={len(value)}"
                    )

                    for index, child in enumerate(value[:10]):
                        print(
                            f"{indent}[{index}]:"
                        )
                        describe_structure(
                            child,
                            depth + 1,
                            max_depth,
                        )

                else:
                    text = str(value)

                    if len(text) > 300:
                        text = text[:300] + "..."

                    print(
                        f"{indent}{type(value).__name__}: {text}"
                    )

            describe_structure(document_layout)

            diagnostic_path = "/tmp/document-layout-diagnostic.json"

            with open(
                diagnostic_path,
                "w",
                encoding="utf-8",
            ) as f:
                json.dump(
                    document_layout,
                    f,
                    indent=2,
                    ensure_ascii=False,
                )

            print(
                f">>> DOCUMENT AI document_layout diagnostic "
                f"saved: {diagnostic_path}"
            )

            sample = json.dumps(
                document_layout,
                indent=2,
                ensure_ascii=False,
            )

            print(
                ">>> DOCUMENT AI document_layout JSON SAMPLE START"
            )
            print(sample[:12000])
            print(
                ">>> DOCUMENT AI document_layout JSON SAMPLE END"
            )

        print(">>> DOCUMENT AI DIAGNOSTICS END")

        # IMPORTANT:
        # Downstream behavior remains unchanged.
        return response